<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$qry=mysql_query("insert into assignmenttwo (login, answer_one, answer_two) values('$username','$answer_one','$answer_two')")or die(mysql_error());
if($qry)
{
 header('Location: assignment_two.php');
}
else
{
	print mysql_error();
}


?>

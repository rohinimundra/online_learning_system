<?php
  session_start();
error_reporting(0);
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='http://www.rohinimundra.com/admin/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

  
  
    include_once "connection.php";
    if(isset($_GET['id']))
	{
		$id=$_GET['id'];
			  
			  $result=mysql_query("select * from form where id='$id'",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  {
			  $id=$row['id'];
			  $name=$row['name'];
			  $phone=$row['phone'];
			  $email=$row['email'];
			  $signup_date=$row['signup_date'];
			  $location=$row['location'];
			  $duration=$row['duration'];
			  $payment_type=$row['payment_type'];
			  $payment_one=$row['payment_one'];
			  $payment_one_date=$row['payment_one_date'];
			  $payment_two=$row['payment_two'];
			  $payment_two_date=$row['payment_two_date'];
			  $payment_three=$row['payment_three'];
			  $payment_third_date=$row['payment_third_date'];
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="file_search.php">Click here to go Back!</a>';
				die();
			  }
	}else
	{
		
		header("Location:file_search.php");
		die();
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/colorpicker.css" />
<link rel="stylesheet" href="css/datepicker.css" />
<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class=""><a href="index.html"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li><a href="tables.html"><i class="icon icon-th"></i> <span>Tables</span></a></li>
    <li class="submenu active"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
       <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
   

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Fill-up the form correctly</h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  
<form class="form-horizontal" role="form"  method="post" action="file_update.php" onSubmit="return check();">
    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
         
        </div> 
        
        <div class="widget-content nopadding">
          <div class="control-group">
              <label class="control-label">Serial No. : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="text" class="span11" id="id" name="id" required  value="<?php echo $id ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Name : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="text" class="span11" id="name" name="name" required  value="<?php echo $name ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Phone : <span class="require">*</span></label>
              <div class="controls">
               <input type="text" class="span11" id="phone" name="phone" required value="<?php echo $phone ;?>" onkeypress='validate(event)'>
                
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Email : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="email" class="span11" id="email" name="email" value="<?php echo $email ;?>" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Sign Up Date : <span class="require">*</span></label>
              <div class="controls">
               
                <input type="date" class="span11" id="signup_date" name="signup_date"  value="<?php echo $signup_date ;?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Location : <span class="require">*</span></label>
              <div class="controls">
               
                 <input type="text" class="span11" id="location" name="location" value="<?php echo $location ;?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Duration : <span class="require">*</span></label>
              <div class="controls">
                <input type="text" class="span11" id="duration" name="duration" value="<?php echo $duration ;?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Payment Type : <span class="require">*</span></label>
              <div class="controls">
                <input type="text" class="span11" id="payment_type" name="payment_type" value="<?php echo $payment_type ;?>">
              </div>
            </div>
             </div></div></div>
     
     <div class="span6">
     <div class="widget-box">
     <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          
        </div>
        <div class="widget-content nopadding">

        <div class="control-group">
              <label class="control-label"> Payment Part One : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="text" class="span11" id="payment_one" name="payment_one" value="<?php echo $payment_one ;?>" required onkeypress='validate(event)'>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">First Payment Date : <span class="require">*</span></label>
              <div class="controls">
               <input type="date" class="span11" id="payment_one_date" name="payment_one_date"  value="<?php echo $payment_one_date ;?>" required>
               
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Two :</label>
              <div class="controls">
                 <input type="text" class="span11" id="payment_two" name="payment_two" value="<?php echo $payment_two ;?>" onkeypress='validate(event)'>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Second Payment Date :</label>
              <div class="controls">
                 <input type="date" class="span11" id="payment_two_date" name="payment_two_date" value="<?php echo $payment_two_date ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Three :</label>
              <div class="controls">
                <input type="text" class="span11" id="payment_three" name="payment_three" onkeypress='validate(event)'  value="<?php echo $payment_three ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Third Payment Date :</label>
              <div class="controls">
                 <input type="date" class="span11" id="payment_third_date" name="payment_third_date" value="<?php echo $payment_third_date ;?>" required>
              </div>
            </div>
           
         
           
         
          
        </div>
      </div>
     
              <button type="submit" class="btn btn-success">Please check and update</button>
           
      </form>
  
           
   
      
        </div>
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>

<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];
$qry=mysql_query("insert into assignmentone(login, activities_one,relationships_one,identity_one,activities_two,relationships_two,identity_two,activities_three,relationships_three,identity_three,activities_four,relationships_four,identity_four,activities_five,relationships_five,identity_five,activities_six,relationships_six,identity_six,certainty_one,certainty_two,variety_one,variety_two,significance_one,significance_two,connection_one,connection_two,growth_one,growth_two,contribution_one,contribution_two) values('$username','$activities_one','$relationships_one','$identity_one','$activities_two','$relationships_two','$identity_two','$activities_three','$relationships_three','$identity_three','$activities_four','$relationships_four','$identity_four','$activities_five','$relationships_five','$identity_five','$activities_six','$relationships_six','$identity_six','$certainty_one','$certainty_two','$variety_one','$variety_two','$significance_one','$significance_two','$connection_one','$connection_two','$growth_one','$growth_two','$contribution_one','$contribution_two')")or die(mysql_error());
if($qry)
{
 header('Location: assignment_one_view.php? id='. $row['id'] . '');
}
else
{
	print mysql_error();
}


?>

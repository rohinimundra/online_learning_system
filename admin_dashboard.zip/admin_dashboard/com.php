<?php 
/*ini_set ("SMTP","ssl://smtp.gmail.com");
ini_set ("sendmail_from","mallikarjuna.tech@gmail.com");*/
$servername = "localhost:3306";
$username = "";
$password = "";
$dbname = "rohinimundra";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
            {

                $name = $_POST['name']; // Turn our post into a local variable
                $email = $_POST['email'];
				$phone = $_POST['phone'];
				$signup_date = $_POST['signup_date'];
				$location = $_POST['location'];
				$duration = $_POST['duration'];
				$payment_type = $_POST['duration'];
				$payment_one = $_POST['payment_one'];
				$payment_one_date = $_POST['payment_one_date'];
				$payment_two = $_POST['payment_two'];
				$payment_two_date = $_POST['payment_two_date'];
				$payment_three = $_POST['payment_three'];
				$payment_third_date = $_POST['payment_third_date']; // Turn our post into a local variable

                /*if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))
                      {
                            $msg = 'The email you have entered is invalid, please try again.';// Return Error - Invalid Email

                      } else 

                      {

                     $msg = 'Your account has been made, <br /> please verify it by clicking the activation link that has been send to your email.';// Return Success - Valid Email
                      }*/

                $hash = md5( rand(0,1000) ); // Generate random 32 character hash and assign it to a local variable.
                  // Example output: f4552671f8909587cf485ea990207f3b
                $password = rand(1000,5000); // Generate random number between 1000 and 5000 and assign it to a local variable.
                    // Example output: 4568
    if($payment_two==''){
$payment_two='N/A';
}
    if($payment_two_date==''){
$payment_two_date='N/A';
}
    if($payment_three==''){
$payment_three='N/A';
}
    if($payment_three_date==''){
$payment_three_date='N/A';
}
   $sql =  "INSERT INTO user(name,phone,email,signup_date,location,duration,payment_type,payment_one,payment_one_date,payment_two,payment_two_date,payment_three,payment_third_date,hash) VALUES(
                '". $name ."', 
                '". $phone ."', 
                '". $email ."',
				'". $signup_date ."',
				'". $location ."',
				'". $duration ."',
				'". $payment_type ."',
				'". $payment_one ."',
				'". $payment_one_date ."',
				'". $payment_two ."',
				'". $payment_two_date ."',
				'". $payment_three ."',
				'". $payment_third_date ."',
			    '". $hash ."') " or die(mysql_error());

                $conn->exec($sql);

                 header('Location: file_search.php');
             }

              $to      = $email; // Send email to our user
              $subject = 'Welcome Message'; // Give the email a subject 
              $message = 'Thanks for Registered With Us!'; 

              // Our message above including the link
                                   
              $headers = 'From:beawesome@rohinimundra.com' . "\r\n"; // Set from headers
              mail($to, $subject, $message, $headers); // Send our email
              /*if($conn)

              {
              
          $to       = $email;
          $subject  = 'Testing sendmail.exe';
          $message  = 'Hi, you just received an email using sendmail!';
          $headers  = 'From: mallikarjuna.tech@gmail.com' . "\r\n" .
                      'MIME-Version: 1.0' . "\r\n" .
                      'Content-type: text/html; charset=utf-8';
          if(mail($to, $subject, $message, $headers))
              echo "Email sent";
          else
              echo "Email sending failed";*/


      /*$to = $email;
   $subject = "Confirmation from TutsforWeb to $email";
   $header = "TutsforWeb: Confirmation from TutsforWeb";
   $message = "Please click the link below to verify and activate your account. rn";
   $message .= "http://localhost/dewi/index.html/confirm.php?passkey=$com_code";
   $headers = 'From: mallikarjuna.tech@gmail.com' . "\r\n" .
    'Reply-To: mallikarjuna.tech@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
   $sentmail = mail($to,$subject,$message,$header,$headers);

   if($sentmail)
            {
   echo "Your Confirmation link Has Been Sent To Your Email Address.";
   }
   else
         {
    echo "Cannot send Confirmation link to your e-mail address";
   }*/
  
    
   
    /*<!--echo '<script language="javascript" type="text/javascript">
            alert("New company employee registered ")
             window.location = "company_register.php";
        </script>';-->*/

	}
	catch(PDOException $e){
    echo $sql . "<br>" . $e->getMessage();
    } 
$conn = null;
?>

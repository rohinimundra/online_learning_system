<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='http://www.rohinimundra.com/admin/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div id="header">
  
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
   <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
   
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>
<!--close-top-Header-menu-->
<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch-->
<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li><a href="#"><i class="icon icon-th"></i> <span>Tables</span></a></li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignmentone_file.php">Assignment One</a></li>
        </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignment_two_day_one.php">Day One</a></li>
        <li><a href="assignment_two_day_two.php">Day Two</a></li>
        <li><a href="assignment_two_day_three.php">Day Three</a></li>
         <li><a href="assignment_two_day_four.php">Day Four</a></li>
          <li><a href="assignment_two_day_five.php">Day Five</a></li>
           <li><a href="assignment_two_day_six.php">Day Six</a></li>
            <li><a href="assignment_two_day_seven.php">Day Seven</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Three</span> <span class="label label-important"></span></a>
      <ul>
         <li><a href="assignment_three_day_one.php">Day One</a></li>
        <li><a href="assignment_three_day_two.php">Day Two</a></li>
        <li><a href="assignment_three_day_three.php">Day Three</a></li>
         <li><a href="assignment_three_day_four.php">Day Four</a></li>
          <li><a href="assignment_three_day_five.php">Day Five</a></li>
           <li><a href="assignment_three_day_six.php">Day Six</a></li>
            <li><a href="assignment_three_day_seven.php">Day Seven</a></li>
       
       
      </ul>
    </li>
   

 
</div>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="index.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
    <div class="quick-actions_homepage">
      <ul class="quick-actions">
        <li class="bg_lb"> <a href="index.php"> <i class="icon-dashboard"></i> <span class="label label-important"></span> My Dashboard </a> </li>
        <li class="bg_lo span4"> <a href="form.php"> <i class="icon-th-list"></i> Forms</a> </li>
       
        <li class="bg_ly span3"> <a href="#"> <i class="icon-th"></i> Tables</a> </li>
     
       
 
        <li class="bg_ls span2"> <a href="#"> <i class="icon-pencil"></i>Elements</a> </li>
       

      </ul>
    </div>
<!--End-Action boxes-->    

<!--Chart-box-->    
  
<!--End-Chart-box--> 
    <hr/>
   
<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
</div>

<!--end-Footer-part-->


 
<script src="js/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/matrix.js"></script> 



</body>
</html>

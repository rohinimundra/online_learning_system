
<?php
include("connection.php");
extract($_POST);
$qry=mysql_query("update form_fillup SET name='$name',phone='$phone',email='$email', signup_date='$signup_date',location='$location',duration='$duration',payment_type='$payment_type',payment_one='$payment_one',payment_two='$payment_two',payment_three='$payment_three' where s_no='$s_no'")or die(mysql_error());
if($qry)
{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Succesfully Updated')
        window.location.href='file_edit.php'
        </SCRIPT>");
}
else
{
	print mysql_error();
}




?>

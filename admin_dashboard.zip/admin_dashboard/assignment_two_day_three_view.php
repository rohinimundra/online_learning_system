<?php
session_start();
error_reporting(0);
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='http://www.rohinimundra.com/admin/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

  
  
    include_once "connection.php";
    if(isset($_GET['s_no']))
	{
		$s_no=$_GET['s_no'];
			  
			  $result=mysql_query("select * from assignment_two_day_three where s_no='$s_no'",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  {
					  
					  
				  
			  $s_no=$row['s_no'];
			  $positive_one=$row['positive_one'];
			  $impact_one=$row['impact_one'];
			  $positive_two=$row['positive_two'];
			  $impact_two=$row['impact_two'];
			  $positive_three=$row['positive_three'];
			  $impact_three=$row['impact_three'];
			  $positive_four=$row['positive_four'];
			  $impact_four=$row['impact_four'];
			  $positive_five=$row['positive_five'];
			  $impact_five=$row['impact_five'];
			 
			 
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="assignment_two_day_one.php">Click here to go Back!</a>';
				die();
			  }
	}else
	{
		
		header("Location:file_search.php");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>   <?php
					      $username=$_SESSION['login']  
					     ?>
  <span class="text">Welcome  <?php echo $username;?></span><b class="caret"> </b></a>
       
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li><a href="#"><i class="icon icon-th"></i> <span>Tables</span></a></li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignmentone_file.php">Assignment One</a></li>
        </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignment_two_day_one.php">Day One</a></li>
        <li><a href="assignment_two_day_two.php">Day Two</a></li>
        <li><a href="assignment_two_day_three.php">Day Three</a></li>
         <li><a href="assignment_two_day_four.php">Day Four</a></li>
          <li><a href="assignment_two_day_five.php">Day Five</a></li>
           <li><a href="assignment_two_day_six.php">Day Six</a></li>
            <li><a href="assignment_two_day_seven.php">Day Seven</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Three</span> <span class="label label-important"></span></a>
      <ul>
         <li><a href="assignment_three_day_one.php">Day One</a></li>
        <li><a href="assignment_three_day_two.php">Day Two</a></li>
        <li><a href="assignment_three_day_three.php">Day Three</a></li>
         <li><a href="assignment_three_day_four.php">Day Four</a></li>
          <li><a href="assignment_three_day_five.php">Day Five</a></li>
           <li><a href="assignment_three_day_six.php">Day Six</a></li>
            <li><a href="assignment_three_day_seven.php">Day Seven</a></li>
       
       
      </ul>
    </li>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Assignment 2 – Day Three</h1><br>

</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  
<form class="form-horizontal" role="form"  method="post" action="assignment_two_day_one_insert.php" onSubmit="return check();">

    <div class="span12">
      <div class="widget-box">
       
        
        <div class="widget-content nopadding">
         
           <div style="overflow-x:auto;">
  <table border="1">
  <p style="font-size:18px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-right:10px; color:#000;">Day 3:  Record the impact it has on how your identity code has changed and thus has an impact on the way you handle things in your life.</p>


  <tr style="background-color:#666;">
      <th style="font-size:32px; font-weight:600; color:#000; padding-top:20px; padding-bottom:20px; width:50%">Positive Statement</th>
      <th style="font-size:32px; font-weight:600; color:#000;  padding-top:20px; padding-bottom:20px; width:50%">Impact</th>
     
    </tr>
   
    <tr>
      <td><?php echo $positive_one; ?> </td>
      <td><?php echo $impact_one; ?></td>
     
     </tr>
      <tr>
      <td><?php echo $positive_two; ?> </td>
      <td><?php echo $impact_two; ?></td>
      
     </tr>
      <tr>
      <td><?php echo $positive_three; ?> </td>
      <td><?php echo $impact_three; ?></td>
   
     </tr>
      <tr>
      <td><?php echo $positive_four; ?> </td>
      <td><?php echo $impact_four; ?></td>
     
     </tr>
      <tr>
      <td><?php echo $positive_five; ?> </td>
      <td><?php echo $impact_five; ?></td>
      
     </tr>
     </table><br><br>
 </div>
 <div class="controls"  style="margin-left:10px;">
<button type="submit" class="btn btn-success" name="submit">Save</button>
              </div></form>
            </div>
            </div></div></div>
      </div>
    </div>
  </div>
 
</div></div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
